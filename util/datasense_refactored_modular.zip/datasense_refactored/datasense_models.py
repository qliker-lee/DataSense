# -*- coding: utf-8 -*-
"""
DataSense shared data models.
"""

from dataclasses import dataclass
from typing import Optional


@dataclass
class SourceSpec:
    """
    Profiling 대상 데이터 소스 정의.

    source_kind:
        - file: 파일/폴더 기반 입력
        - database: SQL Query 기반 입력
    """
    type: str
    source: str
    extension: str = "all"
    execution_flag: str = "Y"
    source_kind: str = "file"
    source_name: Optional[str] = None
    connection_url: Optional[str] = None


@dataclass
class SourceData:
    """
    Reader가 Processor에 넘기는 표준 데이터 객체.
    """
    data: object
    file_no: int
    source_name: str
    source_path: str
    master_type: str
    record_count: int
    column_count: int
    file_size_mb: float = 0.0
