# -*- coding: utf-8 -*-
"""
DB 입력 + DB 저장 예시.

실제 DB 연결 문자열과 SQL은 환경에 맞게 변경하세요.
"""

from datasense_models import SourceSpec
from main_profile_pipeline import ProfilingPipeline
from sinks.db_result_writer import DatabaseResultWriter


def run_db_to_db_example():
    source_specs = [
        SourceSpec(
            type="Master",
            source_kind="database",
            source="SELECT * FROM CUSTOMER_MASTER",
            source_name="CUSTOMER_MASTER",
            connection_url="postgresql+psycopg2://user:password@host:5432/dbname",
        )
    ]

    writer = DatabaseResultWriter(
        connection_url="postgresql+psycopg2://user:password@host:5432/dbname",
        profile_table="datasense_file_format",
        stats_table="datasense_file_stats",
        if_exists="replace",
    )

    pipeline = ProfilingPipeline(writer=writer)
    pipeline.run(source_specs)


if __name__ == "__main__":
    run_db_to_db_example()
