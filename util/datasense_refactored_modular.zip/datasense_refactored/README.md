# DataSense Profiling Modular Refactoring

## 목적

기존 `DS_11_MasterCodeFormat.py`는 다음 기능이 하나의 클래스에 섞여 있었습니다.

- 메타 파일(`DS_Meta/CodeList_Meta.csv`) 읽기
- 소스 파일 탐색
- CSV/XLSX/PKL 파일 로딩
- 컬럼별 Profiling 처리
- DQ Score 계산
- CSV 결과 저장

본 리팩토링 버전은 이를 다음 모듈로 분리합니다.

```text
입력(Source Reader)
    ↓
처리(Profiling Processor)
    ↓
저장(Result Writer)
    ↓
실행 조립(Pipeline)
```

데이터 처리 로직은 `ColumnProfiler` 기반으로 유지하고, 입력과 저장 모듈만 교체하여 CSV 파일 기반 처리와 DB 기반 처리를 모두 지원할 수 있도록 설계했습니다.

---

## 폴더 구조

```text
datasense_refactored/
│
├── main_profile_pipeline.py
├── datasense_config.py
├── datasense_models.py
├── datasense_utils.py
│
├── sources/
│   ├── __init__.py
│   ├── source_registry.py
│   ├── base_source_reader.py
│   ├── file_source_reader.py
│   └── db_source_reader.py
│
├── processors/
│   ├── __init__.py
│   └── profiling_processor.py
│
└── sinks/
    ├── __init__.py
    ├── base_result_writer.py
    ├── csv_result_writer.py
    └── db_result_writer.py
```

---

## 실행 방법

기존과 동일하게 CSV 파일 기반으로 실행하려면:

```bash
python main_profile_pipeline.py
```

---

## CSV 기반 입력

기본 입력 메타 파일은 다음 경로입니다.

```text
DS_Meta/CodeList_Meta.csv
```

필수 컬럼:

| 컬럼명 | 설명 |
|---|---|
| execution_flag | 실행 여부. Y인 행만 처리 |
| type | Master / Reference / Rule 등 |
| source | 파일 또는 폴더 경로 |
| extension | csv, xlsx, pkl, all 등 |

---

## DB 기반 입력 확장

`db_source_reader.py`의 `DatabaseSourceReader`를 사용하면 SQL Query 결과를 DataFrame으로 읽어 처리할 수 있습니다.

예시 메타 구조:

```python
source_list = [
    {
        "type": "Master",
        "source_kind": "database",
        "source": "SELECT * FROM CUSTOMER_MASTER",
        "source_name": "CUSTOMER_MASTER",
        "connection_url": "postgresql+psycopg2://user:password@host:5432/dbname"
    }
]
```

---

## CSV 결과 저장

기본 저장 파일:

```text
DS_Output/FileFormat.csv
DS_Output/FileStats.csv
```

---

## DB 결과 저장 확장

`db_result_writer.py`의 `DatabaseResultWriter`를 사용하면 Profiling 결과를 DB 테이블에 저장할 수 있습니다.

예시:

```python
from sinks.db_result_writer import DatabaseResultWriter

writer = DatabaseResultWriter(
    connection_url="postgresql+psycopg2://user:password@host:5432/dbname",
    profile_table="datasense_file_format",
    stats_table="datasense_file_stats",
    if_exists="replace"
)
```

---

## 핵심 설계 원칙

- 데이터 처리 로직은 `ProfilingProcessor`에만 존재
- 입력 방식은 `SourceReader`로 교체 가능
- 저장 방식은 `ResultWriter`로 교체 가능
- 향후 DB, API, Object Storage 등으로 확장 가능
