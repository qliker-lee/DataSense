# -*- coding: utf-8 -*-
"""
Profiling Processor.

입력 방식과 저장 방식에 의존하지 않는 순수 처리 모듈입니다.
ColumnProfiler 기반 처리 로직은 이 모듈에만 위치합니다.
"""

import traceback
from datetime import datetime

import pandas as pd

from datasense_config import SAMPLE_ROWS, FILE_FORMAT_COLUMN_ORDER
from datasense_models import SourceData
from datasense_utils import reorder_columns

try:
    from util.DS_Columnprofiler import ColumnProfiler, add_dq_scores
except Exception:
    # 프로젝트 외부에서 문법 확인만 하는 경우를 위한 fallback
    ColumnProfiler = None

    def add_dq_scores(df):
        return df


class ProfilingProcessor:
    def __init__(self, sample_rows: int = SAMPLE_ROWS, random_state: int = 42):
        self.sample_rows = sample_rows
        self.random_state = random_state

    def profile_one(self, source_data: SourceData) -> tuple[list[dict], list[dict]]:
        """
        SourceData 하나를 컬럼별 Profile 결과와 파일 통계 결과로 변환합니다.
        """
        if ColumnProfiler is None:
            raise ImportError("util.DS_Columnprofiler.ColumnProfiler를 import할 수 없습니다.")

        df = source_data.data
        if df is None or len(df) == 0:
            return [], []

        total_rows = len(df)
        sample_size = min(total_rows, self.sample_rows)
        sample_df = df if total_rows <= self.sample_rows else df.sample(n=self.sample_rows, random_state=self.random_state)
        actual_sample_size = len(sample_df)
        sampling_pct = round((actual_sample_size / total_rows * 100) if total_rows > 0 else 0, 2)

        file_stats = [{
            "FileNo": source_data.file_no,
            "FilePath": source_data.source_path,
            "FileName": source_data.source_name,
            "MasterType": source_data.master_type,
            "RecordCnt": total_rows,
            "ColumnCnt": len(df.columns),
            "SamplingRows": actual_sample_size,
            "Sampling(%)": sampling_pct,
            "FileSize": source_data.file_size_mb,
            "WorkDate": datetime.now().strftime("%Y-%m-%d"),
        }]

        col_results = []
        for col in sample_df.columns:
            try:
                res = ColumnProfiler(sample_df, col, sample_size).profile()
                if res:
                    res.update({
                        "MasterType": source_data.master_type,
                        "FileName": source_data.source_name,
                        "FilePath": source_data.source_path,
                        "RecordCnt": total_rows,
                    })
                    col_results.append(res)
            except Exception as e:
                print(f"컬럼 프로파일링 실패: source={source_data.source_name}, column={col}, error={e}")
                print(traceback.format_exc())
                continue

        return col_results, file_stats

    def finalize(self, col_results: list[dict]) -> pd.DataFrame:
        """
        컬럼별 Profile 결과를 최종 DataFrame으로 변환하고 DQ Score 및 컬럼 순서를 적용합니다.
        """
        if not col_results:
            return pd.DataFrame()

        final_df = pd.DataFrame(col_results)

        try:
            final_df = add_dq_scores(final_df)
        except Exception as e:
            print(f"DQ 점수 추가 실패. 계속 진행합니다: {e}")

        final_df = reorder_columns(final_df, FILE_FORMAT_COLUMN_ORDER)
        return final_df

    def build_file_stats_df(self, file_stats: list[dict]) -> pd.DataFrame:
        if not file_stats:
            return pd.DataFrame()
        return pd.DataFrame(file_stats)
