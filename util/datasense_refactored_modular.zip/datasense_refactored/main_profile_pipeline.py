# -*- coding: utf-8 -*-
"""
DataSense Profiling Pipeline

입력(Source Reader), 처리(Profiling Processor), 저장(Result Writer)을 분리한 실행 파일입니다.
"""

import time
from pathlib import Path

import pandas as pd

from datasense_config import META_PATH
from datasense_models import SourceSpec
from sources.source_registry import SourceReaderRegistry
from processors.profiling_processor import ProfilingProcessor
from sinks.csv_result_writer import CsvResultWriter


def load_source_specs_from_csv(meta_path: Path = META_PATH) -> list[SourceSpec]:
    """
    DS_Meta/CodeList_Meta.csv를 읽어 SourceSpec 목록으로 변환합니다.

    기존 컬럼:
        execution_flag, type, source, extension

    확장 컬럼:
        source_kind      file/database
        source_name      DB Query 결과명 또는 논리명
        connection_url   DB 연결 문자열
    """
    print(f"META_PATH: {meta_path}")

    if not Path(meta_path).exists():
        print(f"메타 파일이 존재하지 않습니다: {meta_path}")
        return []

    meta_df = pd.read_csv(meta_path)

    required_columns = ["execution_flag", "type", "source", "extension"]
    for col in required_columns:
        if col not in meta_df.columns:
            print(f"{meta_path} 파일 구조 점검 : {col} 컬럼이 없습니다.")
            return []

    filtered = meta_df[meta_df["execution_flag"].astype(str).str.upper() == "Y"].copy()
    if filtered.empty:
        print("수행할 소스가 없습니다.")
        return []

    specs = []
    for row in filtered.to_dict(orient="records"):
        specs.append(
            SourceSpec(
                execution_flag=str(row.get("execution_flag", "Y")),
                type=str(row.get("type", "Master")),
                source=str(row.get("source", "")),
                extension=str(row.get("extension", "all")),
                source_kind=str(row.get("source_kind", "file") or "file"),
                source_name=row.get("source_name"),
                connection_url=row.get("connection_url"),
            )
        )

    print(f"수행할 소스 수: {len(specs)} 개")
    return specs


class ProfilingPipeline:
    def __init__(self, processor=None, writer=None, reader_registry=None):
        self.processor = processor or ProfilingProcessor()
        self.writer = writer or CsvResultWriter()
        self.reader_registry = reader_registry or SourceReaderRegistry()

    def run(self, source_specs: list[SourceSpec]) -> bool:
        if not source_specs:
            print("처리할 source_specs가 비어 있습니다.")
            return False

        all_col_results = []
        all_file_stats = []

        for spec in source_specs:
            try:
                reader = self.reader_registry.get(spec.source_kind)
                for source_data in reader.iter_sources(spec):
                    col_results, file_stats = self.processor.profile_one(source_data)
                    all_col_results.extend(col_results)
                    all_file_stats.extend(file_stats)
            except Exception as e:
                print(f"소스 처리 실패: spec={spec}, error={e}")
                continue

        print(f"총 {len(all_col_results)}개 컬럼 결과 수집 완료")

        if not all_col_results:
            print("처리된 컬럼 결과가 없습니다.")
            return False

        profile_df = self.processor.finalize(all_col_results)
        file_stats_df = self.processor.build_file_stats_df(all_file_stats)

        return self.writer.save(profile_df, file_stats_df)


def main():
    start_time = time.time()

    print("=" * 60)
    print("DataSense Data Profiling 시작 - Modular Pipeline")
    print("=" * 60)

    source_specs = load_source_specs_from_csv()
    pipeline = ProfilingPipeline()
    pipeline.run(source_specs)

    elapsed = time.time() - start_time

    print("=" * 60)
    print(f"총 처리 시간: {elapsed:.2f}초")
    print("=" * 60)


if __name__ == "__main__":
    main()
