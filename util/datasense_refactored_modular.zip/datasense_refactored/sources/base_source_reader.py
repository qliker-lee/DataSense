# -*- coding: utf-8 -*-
"""
Source Reader Interface.
"""

from abc import ABC, abstractmethod
from typing import Iterable
from datasense_models import SourceSpec, SourceData


class BaseSourceReader(ABC):
    """
    모든 입력 Reader의 공통 인터페이스.
    파일이든 DB든 Processor는 SourceData만 받도록 설계합니다.
    """

    @abstractmethod
    def iter_sources(self, spec: SourceSpec) -> Iterable[SourceData]:
        raise NotImplementedError
