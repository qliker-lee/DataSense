# -*- coding: utf-8 -*-
"""
Source Reader Registry.
"""

from sources.file_source_reader import FileSourceReader
from sources.db_source_reader import DatabaseSourceReader


class SourceReaderRegistry:
    def __init__(self):
        self._readers = {
            "file": FileSourceReader(),
            "database": DatabaseSourceReader(),
            "db": DatabaseSourceReader(),
        }

    def get(self, source_kind: str):
        key = (source_kind or "file").lower()
        if key not in self._readers:
            raise ValueError(f"지원하지 않는 source_kind 입니다: {source_kind}")
        return self._readers[key]
