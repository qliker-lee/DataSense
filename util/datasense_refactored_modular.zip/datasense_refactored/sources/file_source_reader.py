# -*- coding: utf-8 -*-
"""
File based Source Reader.

CSV / XLSX / PKL 파일을 읽어 SourceData로 변환합니다.
"""

import os
from pathlib import Path
from typing import Iterable

import pandas as pd

from datasense_config import PROJECT_ROOT
from datasense_models import SourceSpec, SourceData
from datasense_utils import normalize_path, get_file_size_mb
from sources.base_source_reader import BaseSourceReader


class FileSourceReader(BaseSourceReader):
    def __init__(self, encodings=None):
        self.encodings = encodings or ["utf-8-sig", "utf-8", "cp949", "euc-kr"]

    def _discover_files(self, source: str, extension: str) -> list[str]:
        source_path = normalize_path(source, PROJECT_ROOT)

        if not os.path.exists(source_path):
            print(f"메타 파일 점검 : 경로가 존재하지 않습니다: {source_path}")
            return []

        ext = str(extension or "all").lower().strip(".")
        target_files = []

        if os.path.isdir(source_path):
            for f in os.listdir(source_path):
                file_ext = os.path.splitext(f)[1].lower().strip(".")
                if ext in ("", "all") or file_ext == ext:
                    target_files.append(os.path.join(source_path, f))
        else:
            file_ext = os.path.splitext(source_path)[1].lower().strip(".")
            if ext in ("", "all") or file_ext == ext:
                target_files.append(source_path)

        return target_files

    def _read_file(self, file_path: str) -> pd.DataFrame | None:
        file_ext = os.path.splitext(file_path)[1].lower().strip(".")

        try:
            if file_ext == "csv":
                for enc in self.encodings:
                    try:
                        return pd.read_csv(file_path, dtype=str, low_memory=False, encoding=enc)
                    except Exception:
                        continue
                print(f"파일 읽기 실패: CSV 인코딩 확인 필요 - {file_path}")
                return None

            if file_ext == "xlsx":
                return pd.read_excel(file_path, dtype=str)

            if file_ext == "pkl":
                return pd.read_pickle(file_path)

            print(f"지원하지 않는 파일 확장자입니다: {file_path}")
            return None

        except Exception as e:
            print(f"파일 읽기 실패: {file_path}, 오류: {e}")
            return None

    def iter_sources(self, spec: SourceSpec) -> Iterable[SourceData]:
        target_files = self._discover_files(spec.source, spec.extension)

        if not target_files:
            print(f"처리할 파일이 없습니다. source={spec.source}, extension={spec.extension}")
            return

        for file_no, file_path in enumerate(target_files, start=1):
            df = self._read_file(file_path)
            if df is None:
                continue

            yield SourceData(
                data=df,
                file_no=file_no,
                source_name=os.path.basename(file_path),
                source_path=normalize_path(file_path, PROJECT_ROOT),
                master_type=spec.type,
                record_count=len(df),
                column_count=len(df.columns),
                file_size_mb=get_file_size_mb(file_path),
            )
