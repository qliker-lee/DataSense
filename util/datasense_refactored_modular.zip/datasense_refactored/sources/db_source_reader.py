# -*- coding: utf-8 -*-
"""
Database based Source Reader.

SQLAlchemy connection_url과 SQL Query를 받아 DataFrame으로 읽어옵니다.

필요 패키지 예시:
    pip install sqlalchemy psycopg2-binary
    pip install sqlalchemy pymysql
    pip install sqlalchemy oracledb
"""

from typing import Iterable
import pandas as pd

from datasense_models import SourceSpec, SourceData
from sources.base_source_reader import BaseSourceReader


class DatabaseSourceReader(BaseSourceReader):
    def iter_sources(self, spec: SourceSpec) -> Iterable[SourceData]:
        if not spec.connection_url:
            raise ValueError("DatabaseSourceReader 사용 시 connection_url이 필요합니다.")

        try:
            from sqlalchemy import create_engine
        except ImportError as e:
            raise ImportError("DB 입력을 사용하려면 sqlalchemy 설치가 필요합니다.") from e

        engine = create_engine(spec.connection_url)

        query = spec.source
        source_name = spec.source_name or "database_query"

        df = pd.read_sql(query, engine)
        df = df.astype(str)

        yield SourceData(
            data=df,
            file_no=1,
            source_name=source_name,
            source_path=query,
            master_type=spec.type,
            record_count=len(df),
            column_count=len(df.columns),
            file_size_mb=0.0,
        )
