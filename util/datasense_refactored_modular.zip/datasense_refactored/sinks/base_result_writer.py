# -*- coding: utf-8 -*-
"""
Result Writer Interface.
"""

from abc import ABC, abstractmethod
import pandas as pd


class BaseResultWriter(ABC):
    @abstractmethod
    def save(self, profile_df: pd.DataFrame, file_stats_df: pd.DataFrame) -> bool:
        raise NotImplementedError
