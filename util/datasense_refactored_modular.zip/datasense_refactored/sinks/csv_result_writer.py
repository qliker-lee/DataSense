# -*- coding: utf-8 -*-
"""
CSV Result Writer.
"""

import pandas as pd
from pathlib import Path

from datasense_config import FORMAT_FILE, STATS_FILE
from sinks.base_result_writer import BaseResultWriter


class CsvResultWriter(BaseResultWriter):
    def __init__(self, format_file: Path = FORMAT_FILE, stats_file: Path = STATS_FILE):
        self.format_file = Path(format_file)
        self.stats_file = Path(stats_file)

    def save(self, profile_df: pd.DataFrame, file_stats_df: pd.DataFrame) -> bool:
        self.format_file.parent.mkdir(parents=True, exist_ok=True)
        self.stats_file.parent.mkdir(parents=True, exist_ok=True)

        if profile_df is not None and not profile_df.empty:
            profile_df.to_csv(self.format_file, index=False, encoding="utf-8-sig")
            print(f"수행 결과 저장: {self.format_file}")
        else:
            print("Profile 결과가 비어 있어 FileFormat 저장을 건너뜁니다.")

        if file_stats_df is not None and not file_stats_df.empty:
            file_stats_df.to_csv(self.stats_file, index=False, encoding="utf-8-sig")
            print(f"파일 통계 결과 저장: {self.stats_file}")
        else:
            print("FileStats 결과가 비어 있어 저장을 건너뜁니다.")

        return True
