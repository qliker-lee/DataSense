# -*- coding: utf-8 -*-
"""
Database Result Writer.

Profiling 결과를 DB 테이블에 저장합니다.

필요 패키지:
    pip install sqlalchemy
"""

import pandas as pd
from sinks.base_result_writer import BaseResultWriter


class DatabaseResultWriter(BaseResultWriter):
    def __init__(
        self,
        connection_url: str,
        profile_table: str = "datasense_file_format",
        stats_table: str = "datasense_file_stats",
        if_exists: str = "replace",
    ):
        self.connection_url = connection_url
        self.profile_table = profile_table
        self.stats_table = stats_table
        self.if_exists = if_exists

    def save(self, profile_df: pd.DataFrame, file_stats_df: pd.DataFrame) -> bool:
        try:
            from sqlalchemy import create_engine
        except ImportError as e:
            raise ImportError("DB 저장을 사용하려면 sqlalchemy 설치가 필요합니다.") from e

        engine = create_engine(self.connection_url)

        if profile_df is not None and not profile_df.empty:
            profile_df.to_sql(self.profile_table, engine, if_exists=self.if_exists, index=False)
            print(f"Profile 결과 DB 저장 완료: {self.profile_table}")
        else:
            print("Profile 결과가 비어 있어 DB 저장을 건너뜁니다.")

        if file_stats_df is not None and not file_stats_df.empty:
            file_stats_df.to_sql(self.stats_table, engine, if_exists=self.if_exists, index=False)
            print(f"FileStats 결과 DB 저장 완료: {self.stats_table}")
        else:
            print("FileStats 결과가 비어 있어 DB 저장을 건너뜁니다.")

        return True
