# -*- coding: utf-8 -*-
"""
Common utility functions.
"""

import os
from pathlib import Path


def normalize_path(path_str, root_path: Path | None = None):
    if path_str is None or str(path_str).strip() == "":
        return path_str

    path_str = os.path.expanduser(os.path.expandvars(str(path_str)))

    if root_path is not None and not os.path.isabs(path_str):
        path_str = str((root_path / path_str).resolve())
    elif not os.path.isabs(path_str):
        path_str = str(Path(path_str).resolve())
    else:
        path_str = str(Path(path_str).resolve())

    return path_str.replace("\\", "/")


def get_file_size_mb(file_path) -> float:
    try:
        return os.path.getsize(file_path) / (1024 * 1024)
    except Exception:
        return 0.0


def reorder_columns(df, preferred_order):
    ordered = [c for c in preferred_order if c in df.columns]
    ordered += [c for c in df.columns if c not in ordered]
    return df[ordered]
