# -*- coding: utf-8 -*-
"""
DataSense Profiling Config
"""

import sys
from pathlib import Path

if getattr(sys, "frozen", False):
    ROOT_PATH = Path(sys.executable).parent
else:
    # 이 파일이 util 또는 별도 패키지 아래 있어도 프로젝트 루트 추정 가능하도록 처리
    ROOT_PATH = Path(__file__).resolve().parents[0]

# 실제 프로젝트에 배치할 경우 필요에 따라 ROOT_PATH를 조정하세요.
PROJECT_ROOT = ROOT_PATH

META_PATH = PROJECT_ROOT / "DS_Meta" / "CodeList_Meta.csv"
OUTPUT_DIR = PROJECT_ROOT / "DS_Output"
FORMAT_FILE = OUTPUT_DIR / "FileFormat.csv"
STATS_FILE = OUTPUT_DIR / "FileStats.csv"

SAMPLE_ROWS = 10000
CHUNK_SIZE = 100000
LARGE_FILE_THRESHOLD_MB = 1000

FILE_FORMAT_COLUMN_ORDER = [
    "FilePath", "FileName", "ColumnName", "MasterType", "PK", "DataType", "OracleType", "DetailDataType",
    "LenCnt", "LenMin", "LenMax", "LenAvg", "LenMode", "RecordCnt", "SampleRows",
    "ValueCnt", "NullCnt", "Null(%)", "UniqueCnt", "Unique(%)", "FormatCnt",
    "Format", "FormatValue", "Format(%)", "Format2nd", "Format2ndValue", "Format2nd(%)",
    "Format3rd", "Format3rdValue", "Format3rd(%)", "FormatTop10", "FormatTopRate", "MinString", "MaxString",
    "ModeString", "MedianString", "ModeCnt", "Mode(%)", "FormatMin", "FormatMax",
    "FormatMode", "FormatMedian", "Format2ndMin", "Format2ndMax", "Format2ndMode",
    "Format2ndMedian", "Format3rdMin", "Format3rdMax", "Format3rdMode", "Format3rdMedian"
]
